    function submitPostForm(event) {
      event.preventDefault();

      // Retrieve values from the form
      const cropType = document.getElementById('cropType').value;
      const location = document.getElementById('location').value;
      const fieldSize = document.getElementById('fieldSize').value;
      const deadline = document.getElementById('deadline').value;
      const cropStatus = document.getElementById('cropStatus').value;

      // Populate the status page with form data
      document.getElementById('statusCropType').innerText = cropType;
      document.getElementById('statusLocation').innerText = location;
      document.getElementById('statusFieldSize').innerText = fieldSize;
      document.getElementById('statusDeadline').innerText = deadline;
      document.getElementById('statusCropStatus').innerText = cropStatus;

      // Switch to the status page
      showStatusPage();
    }

    function previewImage(event) {
      const image = document.getElementById('uploadedImage');
      const file = event.target.files[0];

      if (file) {
        const reader = new FileReader();

        reader.onload = function(e) {
          image.src = e.target.result;
        };

        reader.readAsDataURL(file);
      }
    }

    function showPostForm() {
      document.getElementById('postForm').style.display = 'block';
      document.getElementById('statusPage').style.display = 'none';
    }

    function showStatusPage() {
      document.getElementById('postForm').style.display = 'none';
      document.getElementById('statusPage').style.display = 'block';
    }