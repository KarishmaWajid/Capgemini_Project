window.onload = function() {
    // Retrieve data from localStorage
    document.getElementById('statusCropType').innerText = localStorage.getItem('cropType');
    document.getElementById('statusLocation').innerText = localStorage.getItem('location');
    document.getElementById('statusFieldSize').innerText = localStorage.getItem('fieldSize');
    document.getElementById('statusDeadline').innerText = localStorage.getItem('deadline');
    document.getElementById('statusCropStatus').innerText = localStorage.getItem('cropStatus');
  
    // Retrieve and display uploaded image
    const uploadedImage = localStorage.getItem('uploadedImage');
    if (uploadedImage) {
      document.getElementById('uploadedImage').src = uploadedImage;
    }
  }
  