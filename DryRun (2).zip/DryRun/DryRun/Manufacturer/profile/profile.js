document.addEventListener("DOMContentLoaded", function() {
    const editBtn = document.getElementById("editBtn");
    const editModal = new bootstrap.Modal(document.getElementById('editModal'));
    const editForm = document.getElementById("editForm");
    const profilePhoto = document.getElementById("profilePhoto");
    const profilePhotoUpload = document.getElementById("profilePhotoUpload");

    // Show modal when "Edit" button is clicked
    editBtn.addEventListener("click", function() {
        editModal.show();
    });

    // Handle form submission
    editForm.addEventListener("submit", function(e) {
        e.preventDefault();
        
        // Get the form values
        const name = document.getElementById("name").value;
        const occupation = document.getElementById("occupation").value;
        const location = document.getElementById("location").value;
        const contact = document.getElementById("contact").value;

        // Update the profile info
        document.getElementById("profileName").textContent = name;
        document.getElementById("profileOccupation").textContent = `• ${occupation}`;
        document.getElementById("profileLocation").innerHTML = `<strong>Location:</strong> ${location}`;
        document.getElementById("profileContact").innerHTML = `<strong>Contact:</strong> ${contact}`;

        // Handle profile photo upload if a new photo is selected
        if (profilePhotoUpload.files && profilePhotoUpload.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                profilePhoto.src = e.target.result;
            }
            reader.readAsDataURL(profilePhotoUpload.files[0]);
        }

        // Close the modal
        editModal.hide();
    });
});
