function submitPostForm(event) {
  event.preventDefault();

  // Retrieve values from the form
  const cropType = document.getElementById('cropType').value;
  const location = document.getElementById('location').value;
  const fieldSize = document.getElementById('fieldSize').value;
  const deadline = document.getElementById('deadline').value;
  const cropStatus = document.getElementById('cropStatus').value;

  // Store data in localStorage to pass it to the status page
  localStorage.setItem('cropType', cropType);
  localStorage.setItem('location', location);
  localStorage.setItem('fieldSize', fieldSize);
  localStorage.setItem('deadline', deadline);
  localStorage.setItem('cropStatus', cropStatus);

  // Redirect to status page
  window.location.href = 'status.html';
}

function previewImage(event) {
  const image = document.getElementById('uploadedImage');
  const file = event.target.files[0];

  if (file) {
    const reader = new FileReader();

    reader.onload = function(e) {
      image.src = e.target.result;
      localStorage.setItem('uploadedImage', e.target.result); // Save image to localStorage
    };

    reader.readAsDataURL(file);
  }
}
