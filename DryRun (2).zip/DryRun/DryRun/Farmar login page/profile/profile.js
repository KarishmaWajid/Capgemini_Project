// Toggle the visibility of the edit form
function toggleEditForm() {
    var form = document.getElementById('edit-form');
    form.style.display = (form.style.display === 'none' || form.style.display === '') ? 'block' : 'none';
}

// Save the profile data
function saveProfile() {
    var name = document.getElementById('edit-fullname').value;
    var email = document.getElementById('edit-email').value;
    var phone = document.getElementById('edit-phone').value;
    var birthday = document.getElementById('edit-birthday').value;
    var location = document.getElementById('edit-location').value;

    if (name) document.getElementById('full-name').textContent = name;
    if (name) document.getElementById('name-display').textContent = name;
    if (email) document.getElementById('email').textContent = email;
    if (phone) document.getElementById('phone').textContent = phone;
    if (birthday) document.getElementById('birthday').textContent = birthday;
    if (location) document.getElementById('location').textContent = location;

    toggleEditForm(); // Hide the form after saving
}

// Function to handle the image upload
function loadFile(event) {
    var output = document.getElementById('profile-image');
    output.src = URL.createObjectURL(event.target.files[0]);
}
